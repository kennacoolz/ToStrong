(() => {
  'use strict';

  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const dataEl = document.getElementById('page-data');
  const data = dataEl ? JSON.parse(dataEl.textContent) : {};
  const page = document.body.dataset.page;

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (v === true) node.setAttribute(k, '');
      else if (v !== false && v != null) node.setAttribute(k, v);
    }
    children.flat().forEach((c) => node.append(c));
    return node;
  }

  function localISODate() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  function setCount(n) {
    const badge = $('#workout-count');
    if (!badge) return;
    badge.textContent = n;
    badge.hidden = n === 0;
  }

  // ---------------------------------------------------------------- home page
  function initHome() {
    const exercises = data.exercises || [];
    const groups = data.groups || {};
    const selected = new Set(data.selected || []);
    const picker = $('#picker');
    const panel = $('#panel');
    let current = null;
    let expanded = false;

    async function toggle(id, button) {
      button.disabled = true;
      try {
        const res = await fetch('/api/workout/toggle', {
          method: 'POST',
          headers: { 'X-CSRF-Token': csrf, 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ exercise_id: id }),
        });
        if (!res.ok) throw new Error('request failed');
        const json = await res.json();
        selected.clear();
        json.selected.forEach((x) => selected.add(x));
        setCount(selected.size);
        paintHeart(button, id);
        const review = $('#review-link');
        if (review) review.textContent = `Review my workout (${selected.size})`;
      } catch (e) {
        alert('Sorry, that did not save. Please refresh the page and try again.');
      } finally {
        button.disabled = false;
      }
    }

    function paintHeart(button, id) {
      const on = selected.has(id);
      button.setAttribute('aria-pressed', on ? 'true' : 'false');
      button.textContent = on ? '♥' : '♡';
      button.title = on ? 'Remove from my workout' : 'Add to my workout';
    }

    function renderPanel() {
      const list = exercises.filter((e) => e.group === current);
      const visible = expanded ? list : list.slice(0, 4);
      const items = visible.map((ex) => {
        const heart = el('button', { type: 'button', class: 'heart', 'aria-label': `Add ${ex.name} to my workout` });
        paintHeart(heart, ex.id);
        heart.addEventListener('click', () => toggle(ex.id, heart));
        return el('li', {},
          heart,
          el('div', {},
            el('div', { class: 'ex-name', text: ex.name }),
            el('p', { class: 'ex-meta', text: `${ex.tag} · ${ex.summary}` }),
            el('p', { class: 'ex-form', text: ex.form })));
      });

      const foot = el('div', { class: 'panel-foot' });
      if (list.length > 4) {
        const more = el('button', { type: 'button', class: 'btn-small', text: expanded ? 'Show fewer' : 'More workouts' });
        more.addEventListener('click', () => { expanded = !expanded; renderPanel(); });
        foot.append(more);
      }
      foot.append(el('a', { class: 'btn-small', id: 'review-link', href: '/workout', text: `Review my workout (${selected.size})` }));

      panel.replaceChildren(el('h2', { text: groups[current] }), el('ul', {}, items), foot);
    }

    function choose(group) {
      current = group;
      expanded = false;
      $$('.muscle').forEach((m) => m.classList.toggle('active', m.dataset.group === group));
      $$('.chip').forEach((c) => c.setAttribute('aria-pressed', c.dataset.group === group ? 'true' : 'false'));
      picker.classList.add('has-panel');
      panel.hidden = false;
      renderPanel();
    }

    $$('.muscle').forEach((m) => {
      m.addEventListener('click', () => choose(m.dataset.group));
      m.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); choose(m.dataset.group); }
      });
    });
    $$('.chip').forEach((c) => c.addEventListener('click', () => choose(c.dataset.group)));
  }

  // ------------------------------------------------------------- workout page
  function initWorkout() {
    const form = $('#workout-form');
    if (!form) return;

    const date = $('#date');
    if (date) { const today = localISODate(); date.max = today; date.value = date.value > today ? today : date.value; }

    function renumber(tbody) {
      $$('.set-row', tbody).forEach((row, i) => {
        $('.set-num', row).textContent = i + 1;
        $$('input', row).forEach((inp) => {
          inp.setAttribute('aria-label', inp.getAttribute('aria-label').replace(/set \d+/, `set ${i + 1}`));
        });
      });
    }

    form.addEventListener('click', (e) => {
      const add = e.target.closest('.add-set');
      const remove = e.target.closest('.remove-set');
      if (add) {
        const tbody = $('tbody', add.closest('.exercise-card'));
        const rows = $$('.set-row', tbody);
        const last = rows[rows.length - 1];
        const copy = last.cloneNode(true);
        const [reps, weight] = $$('input', copy);
        reps.value = $$('input', last)[0].value;
        weight.value = $$('input', last)[1].value;
        tbody.append(copy);
        renumber(tbody);
        reps.focus();
      } else if (remove) {
        const tbody = remove.closest('tbody');
        const row = remove.closest('.set-row');
        if ($$('.set-row', tbody).length > 1) row.remove();
        else $$('input', row).forEach((i) => { i.value = ''; });
        renumber(tbody);
      }
    });
  }

  // ------------------------------------------------------------- history page
  function initHistory() {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-confirm]');
      if (btn && !confirm(btn.dataset.confirm)) e.preventDefault();
    });
  }

  // ------------------------------------------------------------ progress page
  function initProgress() {
    const subject = $('#subject');
    const metricSel = $('#metric');
    const chart = $('#chart');
    const title = $('#chart-title');
    const summary = $('#chart-summary');
    const emptyNote = $('#chart-empty');
    const table = $('#data-table');
    let result = null;

    subject.value = data.initial || subject.options[0].value;
    if (subject.value !== data.initial) subject.selectedIndex = 0;

    const fmt = (n) => (Number.isInteger(n) ? String(n) : (Math.round(n * 10) / 10).toString());
    const fmtDate = (iso, long = false) => {
      const d = new Date(`${iso}T00:00:00`);
      return d.toLocaleDateString(undefined, long ? { month: 'short', day: 'numeric', year: 'numeric' } : { month: 'short', day: 'numeric' });
    };

    function metricsFor(r) {
      const u = r.unit === 'sec' ? 'sec' : 'reps';
      const out = [];
      if (r.has_weight) out.push({ key: 'volume', label: 'Total volume (lb)', short: 'Volume (lb)' });
      if (r.kind === 'exercise') {
        out.push(r.has_weight
          ? { key: 'best_weight', label: 'Heaviest weight (lb)', short: 'Heaviest (lb)' }
          : { key: 'best_reps', label: `Best set (${u})`, short: `Best set (${u})` });
        out.push({ key: 'reps', label: `Total ${u}`, short: `Total ${u}` });
      } else {
        out.push({ key: 'reps', label: 'Total reps (timed holds excluded)', short: 'Reps' });
      }
      out.push({ key: 'sets', label: 'Total sets', short: 'Sets' });
      return out;
    }

    function niceStep(max) {
      const raw = max / 4;
      const pow = Math.pow(10, Math.floor(Math.log10(raw || 1)));
      const n = raw / pow;
      return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * pow;
    }

    function svg(tag, attrs = {}, text) {
      const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
      for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
      if (text != null) node.textContent = text;
      return node;
    }

    function draw(points, metric) {
      const W = 720, H = 320, m = { l: 54, r: 22, t: 20, b: 42 };
      const iw = W - m.l - m.r, ih = H - m.t - m.b;
      const values = points.map((p) => p[metric.key]);
      const step = niceStep(Math.max(...values, 1));
      const top = Math.max(step * Math.ceil(Math.max(...values, 1) / step), step);
      const times = points.map((p) => new Date(`${p.date}T00:00:00`).getTime());
      const t0 = times[0], t1 = times[times.length - 1];
      const x = (i) => (points.length === 1 ? m.l + iw / 2 : m.l + ((times[i] - t0) / (t1 - t0)) * iw);
      const y = (v) => m.t + ih - (v / top) * ih;

      const root = svg('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': `${metric.label} over time` });
      for (let v = 0; v <= top + 1e-9; v += step) {
        root.append(svg('line', { class: 'grid', x1: m.l, x2: W - m.r, y1: y(v), y2: y(v) }));
        root.append(svg('text', { class: 'axis-label', x: m.l - 8, y: y(v) + 4, 'text-anchor': 'end' }, fmt(v)));
      }
      const labelEvery = Math.max(1, Math.ceil(points.length / 6));
      points.forEach((p, i) => {
        if (i % labelEvery === 0 || i === points.length - 1) {
          root.append(svg('text', { class: 'axis-label', x: x(i), y: H - 14, 'text-anchor': 'middle' }, fmtDate(p.date)));
        }
      });
      root.append(svg('polyline', { class: 'line', points: points.map((p, i) => `${x(i)},${y(p[metric.key])}`).join(' ') }));
      points.forEach((p, i) => {
        const dot = svg('circle', { class: 'dot', cx: x(i), cy: y(p[metric.key]), r: 5 });
        dot.append(svg('title', {}, `${fmtDate(p.date, true)}: ${fmt(p[metric.key])}`));
        root.append(dot);
      });
      chart.replaceChildren(root);
      chart.setAttribute('aria-label', `${metric.label} over time for ${result.title}`);
    }

    function summarize(points, metric) {
      const first = points[0][metric.key], last = points[points.length - 1][metric.key];
      const best = Math.max(...points.map((p) => p[metric.key]));
      let text = `${points.length} workout day${points.length === 1 ? '' : 's'} · latest ${fmt(last)} · best ${fmt(best)}`;
      if (points.length > 1 && first > 0) {
        const pct = Math.round(((last - first) / first) * 100);
        text += ` · ${pct >= 0 ? '+' : ''}${pct}% since ${fmtDate(points[0].date, true)}`;
      }
      summary.textContent = text;
    }

    function renderTable(points, metrics) {
      const head = el('tr', {}, el('th', { scope: 'col', text: 'Date' }), metrics.map((mm) => el('th', { scope: 'col', text: mm.short })));
      $('thead', table).replaceChildren(head);
      $('tbody', table).replaceChildren(...points.slice().reverse().map((p) =>
        el('tr', {}, el('td', { text: fmtDate(p.date, true) }), metrics.map((mm) => el('td', { text: fmt(p[mm.key]) })))));
      table.hidden = false;
    }

    function render() {
      const metrics = metricsFor(result);
      const keep = metricSel.value;
      metricSel.replaceChildren(...metrics.map((mm) => el('option', { value: mm.key, text: mm.label })));
      metricSel.value = metrics.some((mm) => mm.key === keep) ? keep : metrics[0].key;
      title.textContent = result.title;

      if (!result.points.length) {
        chart.replaceChildren();
        summary.textContent = '';
        emptyNote.hidden = false;
        table.hidden = true;
        return;
      }
      emptyNote.hidden = true;
      paint();
      renderTable(result.points, metrics);
    }

    function paint() {
      const metric = metricsFor(result).find((mm) => mm.key === metricSel.value);
      draw(result.points, metric);
      summarize(result.points, metric);
    }

    async function load() {
      const [prefix, ...rest] = subject.value.split(':');
      const id = rest.join(':');
      const qs = new URLSearchParams({ kind: prefix === 'ex' ? 'exercise' : 'group', id });
      title.textContent = 'Loading…';
      try {
        const res = await fetch(`/api/progress?${qs}`, { headers: { Accept: 'application/json' } });
        if (res.status === 401) { window.location = '/login'; return; }
        if (!res.ok) throw new Error('bad response');
        result = await res.json();
        metricSel.replaceChildren();
        render();
      } catch (e) {
        title.textContent = 'Could not load progress';
        summary.textContent = 'Please refresh the page and try again.';
      }
    }

    subject.addEventListener('change', load);
    metricSel.addEventListener('change', () => result && result.points.length && paint());
    load();
  }

  const inits = { home: initHome, workout: initWorkout, history: initHistory, progress: initProgress };
  if (inits[page]) inits[page]();
})();
