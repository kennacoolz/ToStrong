#!/usr/bin/env ruby
# frozen_string_literal: true

# End-to-end check against a running server:
#   ruby app.rb &            (or DATA_FILE=/tmp/test.json PORT=4599 ruby app.rb &)
#   BASE=http://127.0.0.1:4599 ruby test/smoke_test.rb
require 'net/http'
require 'uri'
require 'json'
require 'date'

BASE = URI(ENV.fetch('BASE', 'http://127.0.0.1:4567'))
$failures = 0

def check(label, condition)
  puts "#{condition ? 'PASS' : 'FAIL'}  #{label}"
  $failures += 1 unless condition
end

class Client
  attr_reader :cookie, :last

  def initialize
    @cookie = nil
  end

  def request(method, path, form = {}, headers = {})
    http = Net::HTTP.new(BASE.host, BASE.port)
    req = method == :get ? Net::HTTP::Get.new(path) : Net::HTTP::Post.new(path)
    req['Cookie'] = @cookie if @cookie
    headers.each { |k, v| req[k] = v }
    if method == :post
      req['Content-Type'] = 'application/x-www-form-urlencoded'
      req.body = URI.encode_www_form(form)
    end
    res = http.request(req)
    if (set = res.get_fields('set-cookie'))
      @cookie = set.map { |c| c.split(';').first }.join('; ')
    end
    @last = res
  end

  def get(path, headers = {}) = request(:get, path, {}, headers)
  def post(path, form = {}, headers = {}) = request(:post, path, form, headers)

  def csrf
    page = get('/forgot').body
    page[/name="csrf-token" content="([^"]+)"/, 1]
  end

  def body = @last.body.to_s.dup.force_encoding('UTF-8')
  def code = @last.code.to_i
  def location = @last['location']
end

suffix = rand(100_000..999_999)
alice_name = "alice#{suffix}"
bob_name = "bob#{suffix}"
pw = 'correct horse battery'

# ---- anonymous access --------------------------------------------------------
a = Client.new
a.get('/')
check('anonymous / redirects to /login', a.code == 303 && a.location == '/login')
a.get('/api/progress?kind=group&id=legs')
check('anonymous API call is 401', a.code == 401)
a.get('/history')
check('anonymous /history redirects', a.code == 303)

# ---- CSRF ----------------------------------------------------------------------
a.post('/register', { username: alice_name, password: pw, confirm: pw })
check('POST without CSRF token is rejected (403)', a.code == 403)
a.post('/register', { _csrf: a.csrf, username: alice_name, password: pw, confirm: pw }, { 'Origin' => 'http://evil.example' })
check('POST from foreign Origin is rejected (403)', a.code == 403)

# ---- registration validation -----------------------------------------------------
a.post('/register', { _csrf: a.csrf, username: 'x', password: pw, confirm: pw })
check('short username rejected', a.code == 422)
a.post('/register', { _csrf: a.csrf, username: alice_name, password: 'short', confirm: 'short' })
check('short password rejected', a.code == 422)
a.post('/register', { _csrf: a.csrf, username: alice_name, password: pw, confirm: 'different pw' })
check('mismatched confirmation rejected', a.code == 422)
a.post('/register', { _csrf: a.csrf, username: alice_name, password: pw, confirm: pw })
check('valid registration redirects home', a.code == 303 && a.location == '/')
a.get('/')
check('home page renders after registering', a.code == 200 && a.body.include?('Choose a muscle group to work'))
check('home page shows username in nav', a.body.include?(alice_name))
check('home page embeds exercise data', a.body.include?('Hammer Curls'))

dup = Client.new
dup.post('/register', { _csrf: dup.csrf, username: alice_name.upcase, password: pw, confirm: pw })
check('duplicate username (case-insensitive) rejected', dup.code == 422)

# ---- login / logout -------------------------------------------------------------------
c = Client.new
c.post('/login', { _csrf: c.csrf, username: alice_name, password: 'wrong password' })
check('wrong password -> 401', c.code == 401)
c.post('/login', { _csrf: c.csrf, username: 'nobody', password: pw })
check('unknown user -> 401', c.code == 401)
old_cookie = c.cookie
c.post('/login', { _csrf: c.csrf, username: alice_name, password: pw })
check('correct login redirects', c.code == 303 && c.location == '/')
check('session id rotates on login', c.cookie != old_cookie)

# ---- building a workout -----------------------------------------------------------------
a.post('/api/workout/toggle', { exercise_id: 'arms-hammer-curl' }, { 'X-CSRF-Token' => a.csrf })
check('toggle with header CSRF works', a.code == 200 && JSON.parse(a.body)['selected'] == ['arms-hammer-curl'])
a.post('/api/workout/toggle', { exercise_id: 'chest-push-up' }, { 'X-CSRF-Token' => a.csrf })
a.post('/api/workout/toggle', { exercise_id: 'core-plank' }, { 'X-CSRF-Token' => a.csrf })
a.post('/api/workout/toggle', { exercise_id: 'no-such-exercise' }, { 'X-CSRF-Token' => a.csrf })
check('unknown exercise rejected', a.code == 422)
a.get('/workout')
check('workout page lists selected exercises', a.body.include?('Hammer Curls') && a.body.include?('Push-Ups') && a.body.include?('Plank'))
check('timed exercise uses seconds', a.body.include?('Seconds'))

# ---- logging -------------------------------------------------------------------------------
token = a.csrf
yesterday = (Date.today - 1).iso8601
a.post('/workout', { _csrf: token, date: (Date.today + 30).iso8601, name: 'future' })
check('future date rejected', a.code == 303 && a.location == '/workout')
a.post('/workout', { _csrf: token, date: yesterday, name: 'empty' })
check('workout with no reps rejected', a.location == '/workout')

def log_form(token, date, name, hammer_weight)
  URI.decode_www_form(URI.encode_www_form([
    ['_csrf', token], ['date', date], ['name', name],
    ['reps_arms-hammer-curl[]', '12'], ['weight_arms-hammer-curl[]', hammer_weight],
    ['reps_arms-hammer-curl[]', '10'], ['weight_arms-hammer-curl[]', hammer_weight],
    ['reps_arms-hammer-curl[]', ''],   ['weight_arms-hammer-curl[]', ''],
    ['reps_chest-push-up[]', '15'],    ['weight_chest-push-up[]', ''],
    ['reps_core-plank[]', '45'],       ['weight_core-plank[]', '']
  ]))
end

# Net::HTTP helper for repeated keys
def raw_post(client, path, pairs)
  http = Net::HTTP.new(BASE.host, BASE.port)
  req = Net::HTTP::Post.new(path)
  req['Cookie'] = client.cookie
  req['Content-Type'] = 'application/x-www-form-urlencoded'
  req.body = URI.encode_www_form(pairs)
  http.request(req)
end

bad = raw_post(a, '/workout', log_form(token, yesterday, 'bad', '9999'))
check('absurd weight rejected', bad['location'] == '/workout')

res = raw_post(a, '/workout', log_form(token, yesterday, 'Push day', '20'))
check('valid workout logged -> /history', res.code == '303' && res['location'] == '/history')

a.get('/workout')
check('draft cleared after logging', a.body.include?("haven't picked any exercises"))

# second, later session with more weight so progress shows a trend
a.post('/api/workout/toggle', { exercise_id: 'arms-hammer-curl' }, { 'X-CSRF-Token' => a.csrf })
res = raw_post(a, '/workout', [
  ['_csrf', a.csrf], ['date', Date.today.iso8601], ['name', ''],
  ['reps_arms-hammer-curl[]', '12'], ['weight_arms-hammer-curl[]', '25'],
  ['reps_arms-hammer-curl[]', '12'], ['weight_arms-hammer-curl[]', '25']
])
check('second workout logged', res['location'] == '/history')

a.get('/history')
check('history shows both workouts', a.body.include?('Push day') && a.body.scan('history-card').size >= 2)
check('history compresses identical sets', a.body.include?('2 × 12 reps @ 25 lb'))
check('history shows bodyweight and timed sets', a.body.include?('1 × 15 reps') && a.body.include?('1 × 45 sec'))

# ---- progress ---------------------------------------------------------------------------------
a.get('/api/progress?kind=exercise&id=arms-hammer-curl')
j = JSON.parse(a.body)
check('exercise progress has 2 dated points', j['points'].size == 2 && j['points'][0]['date'] == yesterday)
check('exercise progress volume is correct', j['points'][0]['volume'] == 440.0 && j['points'][1]['volume'] == 600.0)
check('exercise progress flags weights', j['has_weight'] == true)
a.get('/api/progress?kind=group&id=arms')
j = JSON.parse(a.body)
check('group progress aggregates arms', j['points'].size == 2 && j['points'].last['sets'] == 2)
a.get('/api/progress?kind=exercise&id=core-plank')
j = JSON.parse(a.body)
check('timed exercise reports seconds', j['unit'] == 'sec' && j['points'][0]['best_reps'] == 45)
a.get('/api/progress?kind=exercise&id=bogus')
check('bad progress subject -> 422', a.code == 422)
a.get('/progress')
check('progress page renders', a.code == 200 && a.body.include?('id="chart"'))

# ---- data isolation between accounts ---------------------------------------------------------------
b = Client.new
b.post('/register', { _csrf: b.csrf, username: bob_name, password: pw, confirm: pw })
b.get('/history')
check("second user can't see first user's history", b.body.include?('No workouts logged yet'))
b.get('/api/progress?kind=group&id=arms')
check("second user's progress is empty", JSON.parse(b.body)['points'].empty?)
b.get('/workout')
check("second user's draft is empty", b.body.include?("haven't picked any exercises"))
a.get('/history')
wid = a.body[%r{/history/(\d+)/delete}, 1]
b.post("/history/#{wid}/delete", { _csrf: b.csrf })
a.get('/history')
check("another user can't delete my workout", a.body.include?("/history/#{wid}/delete"))

# ---- delete + logout -----------------------------------------------------------------------------------
a.post("/history/#{wid}/delete", { _csrf: a.csrf })
a.get('/history')
check('owner can delete a workout', !a.body.include?("/history/#{wid}/delete"))
a.post('/logout', { _csrf: a.csrf })
check('logout redirects to login', a.location == '/login')
a.get('/history')
check('logged out user is bounced', a.code == 303 && a.location == '/login')

# ---- XSS escaping -----------------------------------------------------------------------------------------
x = Client.new
x.post('/register', { _csrf: x.csrf, username: "x#{suffix}", password: pw, confirm: pw })
x.post('/api/workout/toggle', { exercise_id: 'arms-hammer-curl' }, { 'X-CSRF-Token' => x.csrf })
raw_post(x, '/workout', [['_csrf', x.csrf], ['date', Date.today.iso8601], ['name', '<script>alert(1)</script>'],
                         ['reps_arms-hammer-curl[]', '5'], ['weight_arms-hammer-curl[]', '']])
x.get('/history')
check('workout name is HTML-escaped', x.body.include?('&lt;script&gt;alert(1)&lt;/script&gt;') && !x.body.include?('<script>alert(1)'))

puts
puts $failures.zero? ? 'ALL CHECKS PASSED' : "#{$failures} CHECK(S) FAILED"
exit($failures.zero? ? 0 : 1)
