# frozen_string_literal: true

require 'json'
require 'fileutils'
require 'securerandom'
require 'digest'
require 'time'

# Thread-safe storage. Users, workout drafts and workout history are saved to a
# JSON file (atomic writes). Login sessions and password-reset tokens live in
# memory only, so restarting the server signs everyone out.
class Store
  SESSION_TTL = 7 * 24 * 3600
  RESET_TTL = 30 * 60
  MAX_DRAFT = 30

  def initialize(path)
    @path = path
    @mutex = Mutex.new
    FileUtils.mkdir_p(File.dirname(path))
    @data = File.exist?(path) ? JSON.parse(File.read(path, encoding: 'UTF-8')) : {}
    %w[users drafts counters].each { |k| @data[k] ||= {} }
    @data['workouts'] ||= []
    @sessions = {}
    @resets = {}
  end

  # ---- users ---------------------------------------------------------------

  def create_user(username, password_hash)
    @mutex.synchronize do
      taken = @data['users'].values.any? { |u| u['username'].casecmp?(username) }
      return nil if taken

      id = next_id('user')
      user = { 'id' => id, 'username' => username, 'pw' => password_hash,
               'created_at' => Time.now.utc.iso8601 }
      @data['users'][id.to_s] = user
      persist
      user
    end
  end

  def find_user(id)
    @mutex.synchronize { @data['users'][id.to_s] }
  end

  def find_user_by_name(username)
    @mutex.synchronize { @data['users'].values.find { |u| u['username'].casecmp?(username.to_s) } }
  end

  def set_password(user_id, password_hash)
    @mutex.synchronize do
      user = @data['users'][user_id.to_s]
      return false unless user

      user['pw'] = password_hash
      persist
      true
    end
  end

  # ---- sessions (memory only) ---------------------------------------------

  def create_session(user_id = nil)
    token = SecureRandom.urlsafe_base64(32)
    session = { 'user_id' => user_id, 'csrf' => SecureRandom.urlsafe_base64(24),
                'expires' => Time.now.to_i + SESSION_TTL, 'flash' => nil }
    @mutex.synchronize do
      prune_sessions if @sessions.size > 2000
      @sessions[digest(token)] = session
    end
    [token, session]
  end

  def find_session(token)
    return nil if token.to_s.empty?

    @mutex.synchronize do
      s = @sessions[digest(token)]
      return nil unless s

      if s['expires'] < Time.now.to_i
        @sessions.delete(digest(token))
        return nil
      end
      s
    end
  end

  def destroy_session(token)
    @mutex.synchronize { @sessions.delete(digest(token.to_s)) }
  end

  # ---- workout draft (the exercises a user has "hearted") -------------------

  def draft(user_id)
    @mutex.synchronize { (@data['drafts'][user_id.to_s] || []).dup }
  end

  def toggle_draft(user_id, exercise_id)
    @mutex.synchronize do
      list = (@data['drafts'][user_id.to_s] ||= [])
      if list.include?(exercise_id)
        list.delete(exercise_id)
      elsif list.size < MAX_DRAFT
        list << exercise_id
      end
      persist
      list.dup
    end
  end

  def remove_from_draft(user_id, exercise_id)
    @mutex.synchronize do
      (@data['drafts'][user_id.to_s] || []).delete(exercise_id)
      persist
    end
  end

  def clear_draft(user_id)
    @mutex.synchronize do
      @data['drafts'][user_id.to_s] = []
      persist
    end
  end

  # ---- workout history ------------------------------------------------------

  def add_workout(user_id, date, name, entries)
    @mutex.synchronize do
      workout = { 'id' => next_id('workout'), 'user_id' => user_id, 'date' => date, 'name' => name,
                  'created_at' => Time.now.utc.iso8601, 'entries' => entries }
      @data['workouts'] << workout
      persist
      workout
    end
  end

  def workouts_for(user_id)
    @mutex.synchronize do
      @data['workouts'].select { |w| w['user_id'] == user_id }
                       .sort_by { |w| [w['date'], w['id']] }.reverse
    end
  end

  def delete_workout(user_id, workout_id)
    @mutex.synchronize do
      before = @data['workouts'].size
      @data['workouts'].reject! { |w| w['id'] == workout_id && w['user_id'] == user_id }
      persist
      before != @data['workouts'].size
    end
  end

  # ---- password reset tokens (memory only) ---------------------------------

  def create_reset(user_id)
    token = SecureRandom.urlsafe_base64(32)
    @mutex.synchronize do
      @resets.delete_if { |_, v| v[:expires] < Time.now.to_i }
      @resets[digest(token)] = { user_id: user_id, expires: Time.now.to_i + RESET_TTL }
    end
    token
  end

  def peek_reset(token)
    @mutex.synchronize do
      r = @resets[digest(token.to_s)]
      r && r[:expires] >= Time.now.to_i ? r[:user_id] : nil
    end
  end

  def consume_reset(token)
    @mutex.synchronize do
      r = @resets.delete(digest(token.to_s))
      r && r[:expires] >= Time.now.to_i ? r[:user_id] : nil
    end
  end

  private

  def digest(token)
    Digest::SHA256.hexdigest(token)
  end

  def prune_sessions
    now = Time.now.to_i
    @sessions.delete_if { |_, s| s['expires'] < now }
  end

  def next_id(kind)
    @data['counters'][kind] = @data['counters'].fetch(kind, 0) + 1
  end

  def persist
    tmp = "#{@path}.tmp"
    File.write(tmp, JSON.pretty_generate(@data), encoding: 'UTF-8')
    File.chmod(0o600, tmp)
    File.rename(tmp, @path)
  end
end
