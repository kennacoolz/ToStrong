# frozen_string_literal: true

require 'socket'
require 'timeout'
require 'uri'

# A small threaded HTTP/1.1 server that uses only Ruby's standard library.
# It parses requests, hands them to an app object (anything responding to
# #call(request) and returning a Mini::Response) and writes the response.
module Mini
  REASONS = {
    200 => 'OK', 201 => 'Created', 204 => 'No Content', 302 => 'Found', 303 => 'See Other',
    400 => 'Bad Request', 401 => 'Unauthorized', 403 => 'Forbidden', 404 => 'Not Found',
    405 => 'Method Not Allowed', 413 => 'Payload Too Large', 422 => 'Unprocessable Entity',
    429 => 'Too Many Requests', 500 => 'Internal Server Error', 503 => 'Service Unavailable'
  }.freeze

  def self.decode(str)
    URI.decode_www_form_component(str.to_s).dup.force_encoding('UTF-8').scrub
  rescue ArgumentError
    str.to_s.dup.force_encoding('UTF-8').scrub
  end

  # Parses "a=1&b[]=2&b[]=3" style strings. Keys ending in [] become arrays.
  def self.parse_form(str)
    out = {}
    str.to_s.split('&').each do |pair|
      next if pair.empty?

      key, value = pair.split('=', 2)
      key = decode(key)
      value = decode(value.to_s)
      if key.end_with?('[]')
        (out[key] ||= []) << value
      else
        out[key] = value
      end
    end
    out
  end

  class Request
    attr_reader :method, :path, :query, :headers, :cookies, :body, :ip
    attr_accessor :params

    def initialize(method:, path:, query:, headers:, body:, ip:)
      @method = method
      @path = path
      @query = query
      @headers = headers
      @body = body
      @ip = ip
      @cookies = parse_cookies(headers['cookie'])
      @params = Mini.parse_form(query)
      if (headers['content-type'] || '').start_with?('application/x-www-form-urlencoded')
        @params = @params.merge(Mini.parse_form(body))
      end
    end

    private

    def parse_cookies(header)
      header.to_s.split(';').each_with_object({}) do |part, jar|
        name, value = part.strip.split('=', 2)
        jar[name] = value if name && value
      end
    end
  end

  class Response
    attr_accessor :status, :body
    attr_reader :headers, :cookies

    def initialize(status = 200, body = '', headers = {})
      @status = status
      @body = body
      @headers = { 'Content-Type' => 'text/html; charset=utf-8' }.merge(headers)
      @cookies = []
    end

    def set_cookie(name, value, max_age: nil, secure: false)
      parts = ["#{name}=#{value}", 'Path=/', 'HttpOnly', 'SameSite=Lax']
      parts << "Max-Age=#{max_age}" if max_age
      parts << 'Secure' if secure
      @cookies << parts.join('; ')
    end
  end

  class Server
    MAX_BODY = 1_000_000
    MAX_THREADS = 100
    READ_TIMEOUT = 15

    def initialize(app, host:, port:)
      @app = app
      @host = host
      @port = port
    end

    def run
      server = TCPServer.new(@host, @port)
      @active = 0
      @lock = Mutex.new
      puts "Workout Tracker running at http://#{@host == '0.0.0.0' ? 'localhost' : @host}:#{@port}  (Ctrl+C to stop)"
      trap('INT') { puts "\nShutting down."; exit }
      trap('TERM') { exit }
      loop do
        client = server.accept
        busy = @lock.synchronize { @active >= MAX_THREADS }
        if busy
          client.close
          next
        end
        @lock.synchronize { @active += 1 }
        Thread.new(client) do |sock|
          handle(sock)
        ensure
          @lock.synchronize { @active -= 1 }
        end
      end
    end

    private

    def handle(sock)
      sock.setsockopt(Socket::IPPROTO_TCP, Socket::TCP_NODELAY, 1)
      request = Timeout.timeout(READ_TIMEOUT) { read_request(sock) }
      return unless request

      if request.is_a?(Integer)
        write(sock, Response.new(request, "#{REASONS[request]}\n", 'Content-Type' => 'text/plain'))
        return
      end
      write(sock, @app.call(request))
    rescue Timeout::Error, EOFError, Errno::ECONNRESET, Errno::EPIPE, IOError, Errno::ETIMEDOUT
      nil
    rescue StandardError, ScriptError => e
      warn "#{e.class}: #{e.message}\n#{e.backtrace.first(5).join("\n")}"
      begin
        write(sock, Response.new(500, "Internal Server Error\n", 'Content-Type' => 'text/plain'))
      rescue StandardError
        nil
      end
    ensure
      sock.close unless sock.closed?
    end

    def read_request(sock)
      line = sock.gets("\r\n", 8192)
      return nil if line.nil?

      method, target, version = line.strip.split(' ', 3)
      return 400 unless method && target && version.to_s.start_with?('HTTP/')

      headers = {}
      loop do
        h = sock.gets("\r\n", 8192)
        return 400 if h.nil?
        break if h == "\r\n" || h == "\n"
        return 400 if headers.size > 100

        name, value = h.split(':', 2)
        return 400 unless value

        headers[name.strip.downcase] = value.strip
      end

      return 405 unless %w[GET POST].include?(method)

      length = headers['content-length'].to_i
      return 413 if length > MAX_BODY

      body = length.positive? ? sock.read(length).to_s : ''
      path, query = target.split('?', 2)
      peer = sock.peeraddr(false)[3] rescue 'unknown'
      Request.new(method: method, path: path, query: query.to_s, headers: headers, body: body, ip: peer)
    end

    def write(sock, res)
      body = res.body.to_s
      lines = ["HTTP/1.1 #{res.status} #{REASONS[res.status] || 'OK'}"]
      res.headers.each { |k, v| lines << "#{k}: #{v}" }
      res.cookies.each { |c| lines << "Set-Cookie: #{c}" }
      lines << "Content-Length: #{body.bytesize}"
      lines << 'Connection: close'
      sock.write(lines.join("\r\n") + "\r\n\r\n" + body)
    end
  end
end
