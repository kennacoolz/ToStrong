# frozen_string_literal: true

require 'openssl'
require 'securerandom'

# Salted PBKDF2-HMAC-SHA256 password hashing (OpenSSL, no extra gems).
module Passwords
  ITERATIONS = 600_000

  def self.hash(password)
    salt = SecureRandom.random_bytes(16)
    digest = OpenSSL::PKCS5.pbkdf2_hmac(password, salt, ITERATIONS, 32, 'sha256')
    "pbkdf2-sha256$#{ITERATIONS}$#{salt.unpack1('H*')}$#{digest.unpack1('H*')}"
  end

  def self.verify(password, stored)
    _scheme, iterations, salt_hex, hash_hex = stored.to_s.split('$')
    return false unless iterations && salt_hex && hash_hex

    actual = OpenSSL::PKCS5.pbkdf2_hmac(password, [salt_hex].pack('H*'), iterations.to_i, 32, 'sha256')
    expected = [hash_hex].pack('H*')
    actual.bytesize == expected.bytesize && OpenSSL.fixed_length_secure_compare(actual, expected)
  end

  # Used to spend the same time on unknown usernames as on real ones.
  DUMMY = hash('not-a-real-password')
end
