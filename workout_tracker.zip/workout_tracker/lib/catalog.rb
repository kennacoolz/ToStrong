# frozen_string_literal: true

# The exercise library. Add or edit exercises here; every exercise needs a
# unique id, a group (legs / arms / core / chest), recommended sets and reps,
# and a short note on proper form. Use unit: 'sec' for timed holds.
module Catalog
  GROUPS = {
    'legs'  => { label: 'Legs' },
    'arms'  => { label: 'Arms' },
    'core'  => { label: 'Core' },
    'chest' => { label: 'Chest' }
  }.freeze

  EXERCISES = [
    # ---- Arms -------------------------------------------------------------
    { id: 'arms-hammer-curl', group: 'arms', tag: 'Biceps', name: 'Hammer Curls', sets: 3, reps: 12,
      form: 'Curl the dumbbells with a neutral grip while keeping your elbows close to your sides.' },
    { id: 'arms-preacher-curl', group: 'arms', tag: 'Biceps', name: 'Preacher Curls', sets: 3, reps: 10,
      form: 'Rest your upper arms on the preacher pad and curl the weight slowly without lifting your elbows.' },
    { id: 'arms-concentration-curl', group: 'arms', tag: 'Biceps', name: 'Concentration Curls', sets: 3, reps: 12,
      note: 'each arm',
      form: 'Sit down, brace your elbow against your inner thigh, and curl the dumbbell toward your shoulder with control.' },
    { id: 'arms-incline-curl', group: 'arms', tag: 'Biceps', name: 'Incline Dumbbell Curls', sets: 3, reps: 10,
      form: 'Sit on an incline bench, let your arms hang behind you, and curl the dumbbells toward your shoulders while keeping your elbows still.' },
    { id: 'arms-triceps-pushdown', group: 'arms', tag: 'Triceps', name: 'Triceps Pushdowns', sets: 3, reps: 12,
      form: 'Pin your elbows to your sides and press the cable bar down until your arms are straight, then return slowly.' },
    { id: 'arms-overhead-extension', group: 'arms', tag: 'Triceps', name: 'Overhead Triceps Extension', sets: 3, reps: 12,
      form: 'Hold one dumbbell overhead with both hands, lower it behind your head by bending only the elbows, then press up.' },
    { id: 'arms-bench-dip', group: 'arms', tag: 'Triceps', name: 'Bench Dips', sets: 3, reps: 10,
      form: 'Hands on a bench behind you, lower your hips until elbows reach about 90 degrees, then push back up.' },
    { id: 'arms-skull-crusher', group: 'arms', tag: 'Triceps', name: 'Skull Crushers', sets: 3, reps: 10,
      form: 'Lie on a bench and lower the bar toward your forehead by bending the elbows only, then extend without flaring them.' },

    # ---- Chest ------------------------------------------------------------
    { id: 'chest-bench-press', group: 'chest', tag: 'Chest', name: 'Barbell Bench Press', sets: 4, reps: 8,
      form: 'Feet planted, shoulder blades squeezed together. Lower the bar to mid-chest and press up in a slight arc.' },
    { id: 'chest-incline-press', group: 'chest', tag: 'Upper chest', name: 'Incline Dumbbell Press', sets: 3, reps: 10,
      form: 'Set the bench to about 30 degrees. Press the dumbbells up and slightly together without locking your elbows hard.' },
    { id: 'chest-push-up', group: 'chest', tag: 'Chest', name: 'Push-Ups', sets: 3, reps: 15,
      form: 'Keep a straight line from head to heels, lower your chest to just above the floor, and press up.' },
    { id: 'chest-dumbbell-fly', group: 'chest', tag: 'Chest', name: 'Dumbbell Flys', sets: 3, reps: 12,
      form: 'With a soft bend in the elbows, open your arms wide until you feel a stretch, then squeeze back together.' },
    { id: 'chest-cable-crossover', group: 'chest', tag: 'Chest', name: 'Cable Crossovers', sets: 3, reps: 12,
      form: 'Step forward with a slight lean, sweep the handles down and together in front of your hips, and control the return.' },
    { id: 'chest-decline-press', group: 'chest', tag: 'Lower chest', name: 'Decline Press', sets: 3, reps: 10,
      form: 'Secure your legs on the decline bench and lower the bar to your lower chest before pressing straight up.' },
    { id: 'chest-dip', group: 'chest', tag: 'Lower chest', name: 'Chest Dips', sets: 3, reps: 8,
      form: 'Lean your torso forward, lower until your shoulders are just below your elbows, then press up.' },
    { id: 'chest-pec-deck', group: 'chest', tag: 'Chest', name: 'Pec Deck Machine', sets: 3, reps: 12,
      form: 'Keep your back against the pad, bring the handles together in front of your chest, and pause briefly.' },

    # ---- Core -------------------------------------------------------------
    { id: 'core-plank', group: 'core', tag: 'Abs', name: 'Plank', sets: 3, reps: 45, unit: 'sec',
      form: 'Forearms on the floor, body in a straight line. Brace your abs and do not let your hips sag or rise.' },
    { id: 'core-crunch', group: 'core', tag: 'Abs', name: 'Crunches', sets: 3, reps: 20,
      form: 'Lie on your back with knees bent, lift your shoulder blades off the floor, and lower slowly without pulling on your neck.' },
    { id: 'core-bicycle', group: 'core', tag: 'Obliques', name: 'Bicycle Crunches', sets: 3, reps: 20,
      note: 'total',
      form: 'Bring opposite elbow toward opposite knee while extending the other leg, rotating through your torso.' },
    { id: 'core-hanging-knee-raise', group: 'core', tag: 'Lower abs', name: 'Hanging Knee Raises', sets: 3, reps: 12,
      form: 'Hang from a bar, curl your knees toward your chest without swinging, and lower with control.' },
    { id: 'core-russian-twist', group: 'core', tag: 'Obliques', name: 'Russian Twists', sets: 3, reps: 20,
      note: 'total',
      form: 'Lean back slightly with your chest lifted and rotate your torso side to side, touching the weight down each time.' },
    { id: 'core-dead-bug', group: 'core', tag: 'Deep core', name: 'Dead Bugs', sets: 3, reps: 10,
      note: 'each side',
      form: 'Press your lower back into the floor and extend opposite arm and leg slowly without arching.' },
    { id: 'core-mountain-climber', group: 'core', tag: 'Abs', name: 'Mountain Climbers', sets: 3, reps: 30, unit: 'sec',
      form: 'From a high plank, drive your knees toward your chest alternately while keeping your hips level.' },
    { id: 'core-leg-raise', group: 'core', tag: 'Lower abs', name: 'Lying Leg Raises', sets: 3, reps: 12,
      form: 'Lie flat, keep your legs straight, raise them to vertical, and lower them without letting your back arch.' },

    # ---- Legs -------------------------------------------------------------
    { id: 'legs-back-squat', group: 'legs', tag: 'Quads', name: 'Barbell Back Squat', sets: 4, reps: 8,
      form: 'Bar across your upper back, feet shoulder-width. Sit down and back until thighs are parallel, then drive up through your heels.' },
    { id: 'legs-walking-lunge', group: 'legs', tag: 'Quads & glutes', name: 'Walking Lunges', sets: 3, reps: 12,
      note: 'each leg',
      form: 'Take a long step, lower your back knee toward the floor, keep your torso upright, and push through the front heel.' },
    { id: 'legs-romanian-deadlift', group: 'legs', tag: 'Hamstrings', name: 'Romanian Deadlift', sets: 3, reps: 10,
      form: 'Soft knees, hinge at the hips with a flat back until you feel a hamstring stretch, then squeeze your glutes to stand.' },
    { id: 'legs-leg-press', group: 'legs', tag: 'Quads', name: 'Leg Press', sets: 4, reps: 10,
      form: 'Feet shoulder-width on the platform, lower until knees reach about 90 degrees, and press without locking out.' },
    { id: 'legs-goblet-squat', group: 'legs', tag: 'Quads', name: 'Goblet Squat', sets: 3, reps: 12,
      form: 'Hold a dumbbell at your chest, keep your elbows inside your knees at the bottom, and stand tall.' },
    { id: 'legs-split-squat', group: 'legs', tag: 'Quads & glutes', name: 'Bulgarian Split Squat', sets: 3, reps: 10,
      note: 'each leg',
      form: 'Rear foot on a bench, lower straight down until your front thigh is parallel, then drive up through the front foot.' },
    { id: 'legs-calf-raise', group: 'legs', tag: 'Calves', name: 'Standing Calf Raise', sets: 4, reps: 15,
      form: 'Rise onto the balls of your feet as high as you can, pause at the top, and lower below the step for a full stretch.' },
    { id: 'legs-glute-bridge', group: 'legs', tag: 'Glutes', name: 'Glute Bridge', sets: 3, reps: 15,
      form: 'Lie on your back with knees bent, press through your heels to lift your hips, and squeeze your glutes at the top.' }
  ].freeze

  BY_ID = EXERCISES.to_h { |e| [e[:id], e] }.freeze

  def self.find(id)
    BY_ID[id]
  end

  def self.group_label(group)
    GROUPS.dig(group, :label) || group.to_s.capitalize
  end

  def self.unit(exercise)
    exercise && exercise[:unit] == 'sec' ? 'sec' : 'reps'
  end
end
