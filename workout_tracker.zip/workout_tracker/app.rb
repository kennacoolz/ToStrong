#!/usr/bin/env ruby
# frozen_string_literal: true

# Workout Tracker - a Ruby web app (standard library only, no gems required).
#
#   ruby app.rb                 # http://localhost:4567
#   PORT=8080 ruby app.rb       # choose a port
#   HOST=0.0.0.0 ruby app.rb    # allow other devices on your network

Encoding.default_external = Encoding::UTF_8
Encoding.default_internal = Encoding::UTF_8

$LOAD_PATH.unshift File.join(__dir__, 'lib')

require 'erb'
require 'json'
require 'date'
require 'time'
require 'cgi'
require 'openssl'
require 'mini_server'
require 'passwords'
require 'store'
require 'catalog'

ROOT = __dir__
STORE = Store.new(ENV.fetch('DATA_FILE', File.join(ROOT, 'data', 'db.json')))

class WorkoutApp
  Route = Struct.new(:verb, :regex, :method_name)
  ROUTES = []
  TEMPLATES = {}
  TEMPLATE_LOCK = Mutex.new
  ATTEMPTS = Hash.new { |h, k| h[k] = [] }
  ATTEMPTS_LOCK = Mutex.new

  MIME = {
    '.css' => 'text/css; charset=utf-8', '.js' => 'application/javascript; charset=utf-8',
    '.svg' => 'image/svg+xml', '.png' => 'image/png', '.ico' => 'image/x-icon'
  }.freeze

  CSP = [
    "default-src 'self'", "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    'font-src https://fonts.gstatic.com', "img-src 'self' data:", "script-src 'self'",
    "form-action 'self'", "frame-ancestors 'none'", "base-uri 'self'"
  ].join('; ').freeze

  class << self
    %w[GET POST].each do |verb|
      define_method(verb.downcase) do |pattern, &block|
        source = Regexp.escape(pattern).gsub(/:\w+/, '([^/]+)')
        name = :"route_#{verb}_#{ROUTES.size}"
        define_method(name, &block) # a real method, so `return` works inside route bodies
        ROUTES << Route.new(verb, /\A#{source}\z/, name)
      end
    end

    def call(request)
      new(request).call
    end
  end

  def initialize(request)
    @req = request
  end

  # ------------------------------------------------------------------ plumbing

  def call
    load_session
    response = catch(:halt) { dispatch }
    finalize(response)
  end

  def dispatch
    if @req.method == 'GET' && (file = static_file(@req.path))
      return file
    end

    ROUTES.each do |route|
      next unless route.verb == @req.method && (m = route.regex.match(@req.path))

      verify_csrf! if @req.method == 'POST'
      return send(route.method_name, *m.captures.map { |c| Mini.decode(c) })
    end
    not_found
  end

  def load_session
    token = @req.cookies['sid']
    @sess = STORE.find_session(token)
    @sess_token = token if @sess
    return if @sess

    @sess_token, @sess = STORE.create_session
    @issue_cookie = true
  end

  def finalize(res)
    if @issue_cookie
      res.set_cookie('sid', @sess_token, max_age: Store::SESSION_TTL, secure: secure_request?)
    end
    res.headers['X-Content-Type-Options'] = 'nosniff'
    res.headers['Referrer-Policy'] = 'same-origin'
    res.headers['X-Frame-Options'] = 'DENY'
    res.headers['Content-Security-Policy'] = CSP
    res.headers['Cache-Control'] ||= 'no-store'
    res
  end

  def secure_request?
    ENV['COOKIE_SECURE'] == '1' || @req.headers['x-forwarded-proto'] == 'https'
  end

  def verify_csrf!
    origin = @req.headers['origin']
    host = @req.headers['host']
    if origin && origin != 'null' && host && origin.sub(%r{\Ahttps?://}, '') != host
      halt text('Cross-site request blocked.', 403)
    end

    supplied = (@req.params['_csrf'] || @req.headers['x-csrf-token']).to_s
    expected = @sess['csrf']
    ok = supplied.bytesize == expected.bytesize && OpenSSL.fixed_length_secure_compare(supplied, expected)
    return if ok

    halt text('Your session security token is missing or expired. Go back, refresh the page and try again.', 403)
  end

  def halt(response)
    throw :halt, response
  end

  def static_file(path)
    name = Mini.decode(path)
    return nil if name.include?("\0") || name.split('/').include?('..')

    full = File.expand_path(File.join(ROOT, 'public', name))
    public_root = File.join(ROOT, 'public') + File::SEPARATOR
    return nil unless full.start_with?(public_root) && File.file?(full)

    type = MIME[File.extname(full)] || 'application/octet-stream'
    res = Mini::Response.new(200, File.binread(full), 'Content-Type' => type)
    res.headers['Cache-Control'] = 'no-cache'
    res
  end

  # ------------------------------------------------------------------- helpers

  def params
    @req.params
  end

  def h(value)
    ERB::Util.html_escape(value.to_s)
  end

  def csrf
    @sess['csrf']
  end

  def current_user
    return @user if defined?(@user)

    @user = @sess['user_id'] && STORE.find_user(@sess['user_id'])
  end

  def require_login
    return if current_user

    halt(json({ error: 'Please log in.' }, 401)) if @req.path.start_with?('/api/')
    halt redirect('/login')
  end

  def login_user(user)
    STORE.destroy_session(@sess_token)
    @sess_token, @sess = STORE.create_session(user['id'])
    @issue_cookie = true
    @user = user
  end

  def logout_user
    STORE.destroy_session(@sess_token)
    @sess_token, @sess = STORE.create_session
    @issue_cookie = true
    @user = nil
  end

  def flash!(type, message)
    @sess['flash'] = { 'type' => type, 'msg' => message }
  end

  def pop_flash
    f = @sess['flash']
    @sess['flash'] = nil
    f
  end

  def redirect(location)
    Mini::Response.new(303, '', 'Location' => location)
  end

  def text(body, status = 200)
    Mini::Response.new(status, body, 'Content-Type' => 'text/plain; charset=utf-8')
  end

  def json(obj, status = 200)
    Mini::Response.new(status, JSON.generate(obj), 'Content-Type' => 'application/json; charset=utf-8')
  end

  def render(view, status = 200, title: nil)
    @title = title
    @page = view.to_s
    @content = template(view).result(binding)
    Mini::Response.new(status, template(:layout).result(binding))
  end

  def template(name)
    TEMPLATE_LOCK.synchronize do
      TEMPLATES[name] ||= ERB.new(File.read(File.join(ROOT, 'views', "#{name}.erb"), encoding: 'UTF-8'), trim_mode: '-')
    end
  end

  def not_found
    render(:not_found, 404, title: 'Page not found')
  end

  # Embeds data safely in a <script type="application/json"> tag.
  def json_script(id, obj)
    safe = JSON.generate(obj).gsub('<', '<').gsub('>', '>').gsub('&', '&')
    %(<script type="application/json" id="#{h id}">#{safe}</script>)
  end

  def fmt_date(str)
    Date.parse(str).strftime('%a, %b %-d, %Y')
  rescue ArgumentError
    str.to_s
  end

  def fmt_num(n)
    f = n.to_f
    f == f.to_i ? f.to_i.to_s : f.round(2).to_s
  end

  def describe_sets(sets, unit)
    label = unit == 'sec' ? 'sec' : 'reps'
    sets.chunk_while { |a, b| a['reps'] == b['reps'] && a['weight'] == b['weight'] }.map do |run|
      s = run.first
      weight = s['weight'].to_f.positive? ? " @ #{fmt_num(s['weight'])} lb" : ''
      "#{run.size} × #{s['reps']} #{label}#{weight}"
    end.join(', ')
  end

  def exercise_summary(ex)
    unit = ex[:unit] == 'sec' ? 'sec' : 'reps'
    base = "#{ex[:sets]} sets × #{ex[:reps]} #{unit}"
    ex[:note] ? "#{base} (#{ex[:note]})" : base
  end

  def today
    Date.today
  end

  # ----------------------------------------------------------- login throttling

  def throttle_key(username)
    "#{@req.ip}|#{username.to_s.downcase}"
  end

  def throttled?(key)
    ATTEMPTS_LOCK.synchronize do
      cutoff = Time.now.to_i - 600
      ATTEMPTS[key].reject! { |t| t < cutoff }
      ATTEMPTS[key].size >= 8
    end
  end

  def record_failure(key)
    ATTEMPTS_LOCK.synchronize { ATTEMPTS[key] << Time.now.to_i }
  end

  def clear_failures(key)
    ATTEMPTS_LOCK.synchronize { ATTEMPTS.delete(key) }
  end

  def password_problem(password, confirm)
    return 'Password must be at least 8 characters.' if password.length < 8
    return 'Password must be 128 characters or fewer.' if password.length > 128
    return 'The two passwords do not match.' if password != confirm

    nil
  end

  # -------------------------------------------------------------------- routes

  get '/' do
    require_login
    @selected = STORE.draft(current_user['id'])
    @page_data = {
      exercises: Catalog::EXERCISES.map { |e| e.merge(summary: exercise_summary(e)) },
      groups: Catalog::GROUPS.transform_values { |g| g[:label] },
      selected: @selected
    }
    render(:home, title: 'Choose a muscle group')
  end

  # --- accounts

  get '/login' do
    return redirect('/') if current_user

    @form = {}
    render(:login, title: 'Log in')
  end

  post '/login' do
    username = params['username'].to_s.strip
    password = params['password'].to_s
    key = throttle_key(username)
    @form = { 'username' => username }

    if throttled?(key)
      @error = 'Too many failed attempts. Please wait a few minutes and try again.'
      return render(:login, 429, title: 'Log in')
    end

    user = STORE.find_user_by_name(username)
    ok = Passwords.verify(password[0, 200], user ? user['pw'] : Passwords::DUMMY) && user
    if ok
      clear_failures(key)
      login_user(user)
      flash!('ok', "Welcome back, #{user['username']}!")
      redirect('/')
    else
      record_failure(key)
      @error = 'Incorrect username or password.'
      render(:login, 401, title: 'Log in')
    end
  end

  get '/register' do
    return redirect('/') if current_user

    @form = {}
    render(:register, title: 'Create account')
  end

  post '/register' do
    username = params['username'].to_s.strip
    password = params['password'].to_s
    @form = { 'username' => username }

    @error =
      if !username.match?(/\A[A-Za-z0-9_.-]{3,30}\z/)
        'Username must be 3–30 characters: letters, numbers, dot, dash or underscore.'
      else
        password_problem(password, params['confirm'].to_s)
      end
    return render(:register, 422, title: 'Create account') if @error

    user = STORE.create_user(username, Passwords.hash(password))
    unless user
      @error = 'That username is already taken.'
      return render(:register, 422, title: 'Create account')
    end

    login_user(user)
    flash!('ok', 'Account created. Pick a muscle group to get started!')
    redirect('/')
  end

  post '/logout' do
    logout_user
    flash!('ok', 'You have been logged out.')
    redirect('/login')
  end

  get '/forgot' do
    @form = {}
    render(:forgot, title: 'Forgot password')
  end

  post '/forgot' do
    username = params['username'].to_s.strip
    user = STORE.find_user_by_name(username)
    if user
      token = STORE.create_reset(user['id'])
      # Demo build: there is no email on file, so the reset link goes to the server console.
      puts "[password reset] #{user['username']}: http://#{@req.headers['host']}/reset/#{token}  (valid 30 minutes)"
    end
    flash!('ok', 'If that account exists, a password reset link has been generated. ' \
                 'In this demo build the link is printed in the server console.')
    redirect('/login')
  end

  get '/reset/:token' do |token|
    return render(:reset_invalid, 404, title: 'Reset link expired') unless STORE.peek_reset(token)

    @token = token
    render(:reset, title: 'Reset password')
  end

  post '/reset/:token' do |token|
    @token = token
    @error = password_problem(params['password'].to_s, params['confirm'].to_s)
    return render(:reset, 422, title: 'Reset password') if @error

    user_id = STORE.consume_reset(token)
    return render(:reset_invalid, 404, title: 'Reset link expired') unless user_id

    STORE.set_password(user_id, Passwords.hash(params['password'].to_s))
    flash!('ok', 'Password updated. You can log in now.')
    redirect('/login')
  end

  # --- building a workout

  post '/api/workout/toggle' do
    require_login
    id = params['exercise_id'].to_s
    return json({ error: 'Unknown exercise' }, 422) unless Catalog.find(id)

    json({ selected: STORE.toggle_draft(current_user['id'], id) })
  end

  get '/workout' do
    require_login
    @exercises = STORE.draft(current_user['id']).filter_map { |id| Catalog.find(id) }
    render(:workout, title: 'My workout')
  end

  post '/workout/remove' do
    require_login
    STORE.remove_from_draft(current_user['id'], params['exercise_id'].to_s)
    redirect('/workout')
  end

  post '/workout/clear' do
    require_login
    STORE.clear_draft(current_user['id'])
    flash!('ok', 'Your workout was cleared.')
    redirect('/')
  end

  post '/workout' do
    require_login
    uid = current_user['id']

    date = begin
      Date.iso8601(params['date'].to_s)
    rescue ArgumentError
      nil
    end
    if date.nil? || date < Date.new(2000, 1, 1) || date > today + 1
      flash!('error', 'Please choose a valid date (not in the future).')
      return redirect('/workout')
    end

    entries = []
    STORE.draft(uid).each do |id|
      ex = Catalog.find(id) or next
      reps = Array(params["reps_#{id}[]"])
      weights = Array(params["weight_#{id}[]"])
      sets = []
      reps.each_with_index do |raw_reps, i|
        raw_reps = raw_reps.to_s.strip
        next if raw_reps.empty?

        r = Integer(raw_reps, 10, exception: false)
        raw_w = weights[i].to_s.strip
        w = raw_w.empty? ? 0.0 : Float(raw_w, exception: false)
        unless r && r.between?(1, 999) && w && w >= 0 && w <= 2000
          flash!('error', "Check the numbers for #{ex[:name]}: reps must be 1–999 and weight 0–2000.")
          return redirect('/workout')
        end
        sets << { 'reps' => r, 'weight' => w.round(2) }
      end
      entries << { 'exercise_id' => id, 'sets' => sets } unless sets.empty?
    end

    if entries.empty?
      flash!('error', 'Enter the reps for at least one set to log this workout.')
      return redirect('/workout')
    end

    STORE.add_workout(uid, date.iso8601, params['name'].to_s.strip[0, 60], entries)
    STORE.clear_draft(uid)
    flash!('ok', 'Workout logged! Nice work.')
    redirect('/history')
  end

  # --- history & progress

  get '/history' do
    require_login
    @workouts = STORE.workouts_for(current_user['id']).first(200)
    render(:history, title: 'History')
  end

  post '/history/:id/delete' do |id|
    require_login
    STORE.delete_workout(current_user['id'], id.to_i)
    flash!('ok', 'Workout deleted.')
    redirect('/history')
  end

  get '/progress' do
    require_login
    logged = STORE.workouts_for(current_user['id']).flat_map { |w| w['entries'].map { |e| e['exercise_id'] } }.uniq
    @has_history = !logged.empty?
    @initial = logged.first ? "ex:#{logged.first}" : 'group:legs'
    @initial = "ex:#{params['exercise']}" if Catalog.find(params['exercise'].to_s)
    render(:progress, title: 'Progress')
  end

  get '/api/progress' do
    require_login
    kind = params['kind'].to_s
    id = params['id'].to_s
    if kind == 'exercise' && (ex = Catalog.find(id))
      title = ex[:name]
      unit = Catalog.unit(ex)
    elsif kind == 'group' && Catalog::GROUPS.key?(id)
      title = "All #{Catalog.group_label(id).downcase} exercises"
      unit = 'reps'
    else
      return json({ error: 'Unknown exercise or muscle group' }, 422)
    end

    days = Hash.new { |hash, d| hash[d] = { sets: 0, reps: 0, volume: 0.0, best_weight: 0.0, best_reps: 0 } }
    STORE.workouts_for(current_user['id']).each do |w|
      w['entries'].each do |e|
        exd = Catalog.find(e['exercise_id'])
        match = kind == 'exercise' ? e['exercise_id'] == id : (exd && exd[:group] == id)
        next unless match

        timed = exd && exd[:unit] == 'sec'
        e['sets'].each do |s|
          d = days[w['date']]
          d[:sets] += 1
          d[:reps] += s['reps'] unless timed && kind == 'group'
          d[:volume] += s['reps'] * s['weight'] unless timed
          d[:best_weight] = [d[:best_weight], s['weight']].max
          d[:best_reps] = [d[:best_reps], s['reps']].max
        end
      end
    end

    points = days.sort.map do |date, d|
      d.merge(date: date, volume: d[:volume].round(1), best_weight: d[:best_weight].round(2))
    end
    json({ title: title, kind: kind, unit: unit, points: points,
           has_weight: points.any? { |p| p[:best_weight].positive? } })
  end
end

if $PROGRAM_NAME == __FILE__
  host = ENV.fetch('HOST', '127.0.0.1')
  port = Integer(ENV.fetch('PORT', '4567'))
  Mini::Server.new(WorkoutApp, host: host, port: port).run
end
