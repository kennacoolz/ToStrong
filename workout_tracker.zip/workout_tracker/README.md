# Workout Tracker

A Ruby web app for building, logging and tracking workouts. Each user has a private account; pick a muscle group
on the body diagram (legs, arms, core, chest), browse exercises with recommended sets/reps and form tips, heart the
ones you want, log the session, and watch your progress over time.

**No gems and no installs needed** – it runs on plain Ruby 3.x (tested on 3.3) using only the standard library
(a small built-in HTTP server, ERB templates, OpenSSL for password hashing, a JSON file for storage).

## Run it

```bash
cd workout_tracker
ruby app.rb
# open http://localhost:4567
```

Options: `PORT=8080 ruby app.rb`, `HOST=0.0.0.0 ruby app.rb` (reachable from other devices on your network),
`DATA_FILE=/path/to/db.json` (where accounts and workouts are stored; default `data/db.json`).

Click **Create account**, then pick a muscle group on the diagram.

## Features (mapped to the project plan)

| Planned feature | Where |
|---|---|
| Login / registration, separate private accounts | `/login`, `/register` (PBKDF2-SHA256 hashed passwords, per-user data) |
| Muscle-group categories (legs, arms, core, chest) | Clickable body diagram on `/` (or the buttons beside it) |
| Browsable exercise list with sets/reps + form | Panel beside the diagram; "More workouts" shows the rest (`lib/catalog.rb`) |
| Custom workout from the list | Tap the heart ♡ on exercises → **My Workout** (`/workout`) |
| History logging per user | Log reps/weight per set → **History** (`/history`) |
| Progress tracking & visualisation | **Progress** (`/progress`): chart + table per exercise or per muscle group |

Also included: "Forgot Password?" flow (the reset link prints in the server console because accounts have no email –
swap in a mailer in `post '/forgot'` in `app.rb` if you add one).

## Project layout

```
app.rb              routes, helpers, entry point
lib/mini_server.rb  tiny threaded HTTP server (stdlib only)
lib/store.rb        thread-safe JSON storage + sessions
lib/passwords.rb    PBKDF2 password hashing
lib/catalog.rb      the exercise library – edit/add exercises here
views/*.erb         page templates
public/             style.css, app.js, images
test/smoke_test.rb  end-to-end test (see below)
```

## Adding exercises

Add a hash to `EXERCISES` in `lib/catalog.rb` with a unique `id`, a `group` (`legs`/`arms`/`core`/`chest`), `tag`,
`name`, `sets`, `reps`, `form`. Use `unit: 'sec'` for timed holds. Restart the server.

## Tests

```bash
DATA_FILE=/tmp/test.json PORT=4599 ruby app.rb &
BASE=http://127.0.0.1:4599 ruby test/smoke_test.rb
```

Covers registration/login rules, CSRF protection, logging, progress maths, per-user data isolation, and HTML escaping.

## Security notes

Passwords are salted PBKDF2-SHA256 (600k iterations); sessions use random HttpOnly SameSite cookies that rotate on
login; every POST needs a CSRF token; login attempts are rate-limited; output is HTML-escaped; a strict
Content-Security-Policy is sent. Sessions live in memory (restarting the server logs everyone out). For a public
deployment, put it behind HTTPS (set `COOKIE_SECURE=1`) and consider a real database and mailer.
